create or replace function public.set_emergency_lock(p_enabled boolean,p_actor_id uuid) returns bigint
language plpgsql security definer set search_path=public,auth as $$
declare g bigint;
begin
 if not exists(select 1 from public.admin_roles where user_id=p_actor_id and role='super_admin') then
  raise exception 'Super Admin permission required';
 end if;
 update public.team_ghaith_system_control
 set emergency_locked=p_enabled,generation=generation+1,changed_at=now(),changed_by=p_actor_id,
 change_reason=case when p_enabled then 'MØX//OMEGA emergency lock' else 'Emergency restoration' end
 where singleton_id=1 returning generation into g;
 if p_enabled then
  update public.team_ghaith_member_sessions set revoked_at=now() where revoked_at is null;
  update public.devices set revoked_at=now() where revoked_at is null
   and user_id not in(select user_id from public.admin_roles where role='super_admin');
 end if;
 insert into public.team_ghaith_emergency_events(action,actor_id,generation)
 values(case when p_enabled then 'LOCK' else 'RESTORE' end,p_actor_id,g);
 insert into public.activity_logs(actor_id,action,target_type,details)
 values(p_actor_id,case when p_enabled then 'emergency_lock' else 'emergency_restore' end,'system',jsonb_build_object('generation',g));
 return g;
end;
$$;
revoke all on function public.set_emergency_lock(boolean) from public,anon,authenticated;
revoke all on function public.set_emergency_lock(boolean,uuid) from public,anon,authenticated;
grant execute on function public.set_emergency_lock(boolean,uuid) to service_role;
revoke all on function public.protect_member_card_number() from public,anon,authenticated;
create or replace function public.touch_updated_at() returns trigger
language plpgsql set search_path=public as $$ begin new.updated_at=now(); return new; end; $$;
drop policy if exists settings_admin_read on public.system_settings;
drop policy if exists settings_superadmin_write on public.system_settings;
create policy settings_admin_read on public.system_settings for select to authenticated
 using((select public.member_access_allowed()) and (select public.has_admin_role()));
create policy settings_superadmin_insert on public.system_settings for insert to authenticated
 with check((select public.member_access_allowed()) and (select public.is_super_admin()));
create policy settings_superadmin_update on public.system_settings for update to authenticated
 using((select public.member_access_allowed()) and (select public.is_super_admin()))
 with check((select public.member_access_allowed()) and (select public.is_super_admin()));
create policy settings_superadmin_delete on public.system_settings for delete to authenticated
 using((select public.member_access_allowed()) and (select public.is_super_admin()));
create index if not exists activity_logs_actor_idx on public.activity_logs(actor_id);
create index if not exists card_assets_card_idx on public.card_assets(card_id);
create index if not exists card_assets_user_idx on public.card_assets(user_id);
create index if not exists license_activations_license_idx on public.license_activations(license_id);
create index if not exists licenses_created_by_idx on public.licenses(created_by);
create index if not exists pending_activations_license_idx on public.pending_activations(license_id);
create index if not exists system_settings_updated_by_idx on public.system_settings(updated_by);
create index if not exists emergency_events_actor_idx on public.team_ghaith_emergency_events(actor_id);
create index if not exists member_sessions_user_idx on public.team_ghaith_member_sessions(user_id);
create index if not exists system_control_changed_by_idx on public.team_ghaith_system_control(changed_by);
