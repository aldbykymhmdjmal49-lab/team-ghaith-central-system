create or replace function public.finalize_pending_activation(p_pending_id uuid,p_user_id uuid,p_email text)
returns uuid language plpgsql security definer set search_path=public,auth as $$
declare p public.pending_activations%rowtype; l public.licenses%rowtype; member_no text;
begin
 if public.emergency_is_locked() then raise exception 'System temporarily unavailable'; end if;
 if coalesce((select (value->>'enabled')::boolean from public.system_settings where key='maintenance'),false) then raise exception 'System temporarily unavailable'; end if;
 if coalesce((select (value->>'enabled')::boolean from public.system_settings where key='new_activations'),true)=false then raise exception 'New activations are disabled'; end if;
 select * into p from public.pending_activations where id=p_pending_id and lower(email)=lower(p_email) and consumed_at is null and expires_at>now() for update;
 if not found then raise exception 'Activation request expired or invalid'; end if;
 select * into l from public.licenses where id=p.license_id for update;
 if not found or l.status in ('revoked','suspended','expired') then raise exception 'License unavailable'; end if;
 if l.expires_at is not null and l.expires_at<=now() then update public.licenses set status='expired' where id=l.id; raise exception 'License expired'; end if;
 if l.activation_count>=l.activation_limit then raise exception 'Activation limit reached'; end if;
 if exists(select 1 from public.profiles where id=p_user_id) then raise exception 'Account already activated'; end if;
 member_no := 'TG-' || upper(substr(replace(gen_random_uuid()::text,'-',''),1,10));
 insert into public.profiles(id,full_name,phone,email,member_number,status) values(p_user_id,p.full_name,p.phone,lower(p_email),member_no,'active');
 insert into public.license_activations(license_id,user_id) values(l.id,p_user_id);
 update public.licenses set activation_count=activation_count+1,status='active' where id=l.id;
 update public.pending_activations set consumed_at=now() where id=p.id;
 insert into public.activity_logs(actor_id,action,target_type,target_id,details) values(p_user_id,'license_activated','license',l.id::text,jsonb_build_object('member_number',member_no));
 return l.id;
end; $$;
revoke all on function public.finalize_pending_activation(uuid,uuid,text) from public,anon,authenticated;
grant execute on function public.finalize_pending_activation(uuid,uuid,text) to service_role;
