-- TEAM GHAITH central platform schema. Apply to a NEW Supabase project.
create extension if not exists pgcrypto with schema extensions;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null,
  phone text not null,
  email text not null,
  member_number text unique,
  status text not null default 'active' check (status in ('pending','active','suspended','revoked')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.admin_roles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  role text not null check (role in ('super_admin','admin','viewer')),
  created_at timestamptz not null default now()
);

create table if not exists public.licenses (
  id uuid primary key default gen_random_uuid(),
  code_hash text not null unique,
  code_hint text not null,
  license_type text not null check (license_type in ('permanent','temporary')),
  activation_limit integer not null default 1 check (activation_limit > 0),
  activation_count integer not null default 0 check (activation_count >= 0),
  expires_at timestamptz,
  status text not null default 'unused' check (status in ('unused','active','expired','suspended','revoked')),
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now(),
  note text,
  check ((license_type = 'permanent' and expires_at is null) or license_type = 'temporary')
);

create table if not exists public.license_activations (
  id uuid primary key default gen_random_uuid(),
  license_id uuid not null references public.licenses(id),
  user_id uuid not null unique references auth.users(id) on delete cascade,
  activated_at timestamptz not null default now(),
  status text not null default 'active' check (status in ('active','suspended','revoked'))
);

create table if not exists public.devices (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  session_id uuid not null unique,
  device_label text not null default 'Unknown device',
  user_agent text,
  last_seen_at timestamptz not null default now(),
  revoked_at timestamptz,
  created_at timestamptz not null default now()
);
create index if not exists devices_user_idx on public.devices(user_id);

create table if not exists public.member_cards (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null default 'بطاقتي',
  card_data jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists member_cards_user_idx on public.member_cards(user_id);

create table if not exists public.card_assets (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  card_id uuid references public.member_cards(id) on delete cascade,
  storage_path text not null,
  content_type text,
  created_at timestamptz not null default now()
);

create table if not exists public.system_settings (
  key text primary key,
  value jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now(),
  updated_by uuid references auth.users(id)
);
insert into public.system_settings(key,value) values
 ('maintenance', '{"enabled":false,"message":"النظام تحت الصيانة"}'::jsonb),
 ('device_limit', '{"value":2}'::jsonb),
 ('new_activations', '{"enabled":true}'::jsonb)
on conflict (key) do nothing;

create table if not exists public.activity_logs (
  id bigint generated always as identity primary key,
  actor_id uuid references auth.users(id) on delete set null,
  action text not null,
  target_type text,
  target_id text,
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
create index if not exists activity_logs_created_idx on public.activity_logs(created_at desc);

create table if not exists public.pending_activations (
  id uuid primary key default gen_random_uuid(),
  email text not null,
  full_name text not null,
  phone text not null,
  license_id uuid not null references public.licenses(id),
  expires_at timestamptz not null,
  consumed_at timestamptz,
  created_at timestamptz not null default now()
);
create index if not exists pending_activations_email_idx on public.pending_activations(lower(email), created_at desc);

create table if not exists public.team_ghaith_system_control (
  singleton_id smallint primary key default 1 check (singleton_id = 1),
  emergency_locked boolean not null default false,
  generation bigint not null default 1,
  changed_at timestamptz not null default now(),
  changed_by uuid references auth.users(id),
  change_reason text
);
insert into public.team_ghaith_system_control(singleton_id) values (1) on conflict do nothing;

create table if not exists public.team_ghaith_member_sessions (
  session_id uuid primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  last_seen_at timestamptz not null default now(),
  revoked_at timestamptz
);
create table if not exists public.team_ghaith_emergency_events (
  id bigint generated always as identity primary key,
  action text not null check (action in ('LOCK','RESTORE')),
  actor_id uuid references auth.users(id),
  generation bigint not null,
  created_at timestamptz not null default now()
);

create or replace function public.is_super_admin()
returns boolean language sql stable security definer set search_path=public,auth as $$
 select exists(select 1 from public.admin_roles where user_id=auth.uid() and role='super_admin'); $$;
create or replace function public.has_admin_role()
returns boolean language sql stable security definer set search_path=public,auth as $$
 select exists(select 1 from public.admin_roles where user_id=auth.uid()); $$;
create or replace function public.emergency_is_locked()
returns boolean language sql stable security definer set search_path=public as $$
 select coalesce((select emergency_locked from public.team_ghaith_system_control where singleton_id=1),false); $$;
create or replace function public.maintenance_is_enabled()
returns boolean language sql stable security definer set search_path=public as $$
 select coalesce((select (value->>'enabled')::boolean from public.system_settings where key='maintenance'),false); $$;
create or replace function public.can_manage_system()
returns boolean language sql stable security definer set search_path=public,auth as $$
 select exists(select 1 from public.admin_roles where user_id=auth.uid() and role in ('super_admin','admin'))
 and (public.is_super_admin() or (not public.emergency_is_locked() and not public.maintenance_is_enabled())); $$;
create or replace function public.member_access_allowed()
returns boolean language plpgsql stable security definer set search_path=public,auth as $$
declare sid uuid;
begin
 if auth.uid() is null then return false; end if;
 if public.emergency_is_locked() or public.maintenance_is_enabled() then return public.is_super_admin(); end if;
 if public.has_admin_role() then return true; end if;
 begin sid := (auth.jwt()->>'session_id')::uuid; exception when others then return false; end;
 return exists(select 1 from public.team_ghaith_member_sessions s where s.session_id=sid and s.user_id=auth.uid() and s.revoked_at is null)
   and exists(select 1 from public.profiles p where p.id=auth.uid() and p.status='active')
   and exists(select 1 from public.license_activations a join public.licenses l on l.id=a.license_id where a.user_id=auth.uid() and a.status='active' and l.status='active' and (l.expires_at is null or l.expires_at>now()));
end; $$;
create or replace function public.register_member_session(p_device_label text default null,p_user_agent text default null)
returns boolean language plpgsql security definer set search_path=public,auth as $$
declare sid uuid; active_count integer; max_devices integer;
begin
 if auth.uid() is null then raise exception 'Authentication required'; end if;
 if public.emergency_is_locked() or public.maintenance_is_enabled() then raise exception 'System temporarily unavailable'; end if;
 if public.has_admin_role() then return true; end if;
 if not exists(select 1 from public.profiles p where p.id=auth.uid() and p.status='active') then raise exception 'Membership is not active'; end if;
 if not exists(select 1 from public.license_activations a join public.licenses l on l.id=a.license_id where a.user_id=auth.uid() and a.status='active' and l.status='active' and (l.expires_at is null or l.expires_at>now())) then raise exception 'No valid active license'; end if;
 begin sid := (auth.jwt()->>'session_id')::uuid; exception when others then raise exception 'Session identifier unavailable'; end;
 select coalesce((value->>'value')::integer,2) into max_devices from public.system_settings where key='device_limit';
 select count(*) into active_count from public.team_ghaith_member_sessions where user_id=auth.uid() and revoked_at is null;
 if not exists(select 1 from public.team_ghaith_member_sessions where session_id=sid and user_id=auth.uid() and revoked_at is null) and active_count>=coalesce(max_devices,2) then raise exception 'Device limit reached. Revoke an old device first.'; end if;
 insert into public.team_ghaith_member_sessions(session_id,user_id,last_seen_at,revoked_at)
 values(sid,auth.uid(),now(),null) on conflict(session_id) do nothing;
 if exists(select 1 from public.team_ghaith_member_sessions where session_id=sid and revoked_at is not null) then
   raise exception 'This session was revoked. Sign in again to continue.';
 end if;
 update public.team_ghaith_member_sessions set last_seen_at=now() where session_id=sid and user_id=auth.uid();
 insert into public.devices(user_id,session_id,device_label,user_agent)
 values(auth.uid(),sid,coalesce(nullif(left(p_device_label,80),''),auth.jwt()->>'device_label','Browser device'),left(coalesce(p_user_agent,auth.jwt()->>'user_agent',''),500)) on conflict(session_id) do nothing;
 update public.devices set last_seen_at=now() where session_id=sid and user_id=auth.uid() and revoked_at is null;
 return true;
end; $$;
create or replace function public.set_emergency_lock(p_enabled boolean)
returns bigint language plpgsql security definer set search_path=public,auth as $$
declare g bigint;
begin
 if not public.is_super_admin() then raise exception 'Super Admin permission required'; end if;
 update public.team_ghaith_system_control set emergency_locked=p_enabled,generation=generation+1,changed_at=now(),changed_by=auth.uid(),change_reason=case when p_enabled then 'MØX//OMEGA emergency lock' else 'Emergency restoration' end where singleton_id=1 returning generation into g;
 if p_enabled then
   update public.team_ghaith_member_sessions set revoked_at=now() where revoked_at is null;
   update public.devices set revoked_at=now() where revoked_at is null and user_id not in (select user_id from public.admin_roles where role='super_admin');
 end if;
 insert into public.team_ghaith_emergency_events(action,actor_id,generation) values(case when p_enabled then 'LOCK' else 'RESTORE' end,auth.uid(),g);
 insert into public.activity_logs(actor_id,action,target_type,details) values(auth.uid(),case when p_enabled then 'emergency_lock' else 'emergency_restore' end,'system',jsonb_build_object('generation',g));
 return g;
end; $$;

-- RLS: member records are isolated by auth.uid(); admins get role-scoped access.
alter table public.profiles enable row level security;
alter table public.admin_roles enable row level security;
alter table public.licenses enable row level security;
alter table public.license_activations enable row level security;
alter table public.devices enable row level security;
alter table public.member_cards enable row level security;
alter table public.card_assets enable row level security;
alter table public.system_settings enable row level security;
alter table public.activity_logs enable row level security;
alter table public.pending_activations enable row level security;
alter table public.team_ghaith_system_control enable row level security;
alter table public.team_ghaith_member_sessions enable row level security;
alter table public.team_ghaith_emergency_events enable row level security;

create policy profiles_read_self_or_admin on public.profiles for select to authenticated using ((id=auth.uid() and not public.emergency_is_locked() and not public.maintenance_is_enabled()) or (public.member_access_allowed() and public.has_admin_role()));
create policy profiles_update_self_or_admin on public.profiles for update to authenticated using (public.member_access_allowed() and (id=auth.uid() or public.is_super_admin())) with check (public.member_access_allowed() and (id=auth.uid() or public.is_super_admin()));
create policy admin_roles_read_self_or_superadmin on public.admin_roles for select to authenticated using (user_id=auth.uid() or public.is_super_admin());
create policy licenses_admin_read on public.licenses for select to authenticated using (public.member_access_allowed() and public.has_admin_role());
create policy licenses_admin_manage on public.licenses for update to authenticated using (public.member_access_allowed() and public.can_manage_system()) with check (public.member_access_allowed() and public.can_manage_system());
create policy activations_self_or_admin on public.license_activations for select to authenticated using (public.member_access_allowed() and (user_id=auth.uid() or public.has_admin_role()));
create policy devices_read_self_or_admin on public.devices for select to authenticated using (public.member_access_allowed() and (user_id=auth.uid() or public.has_admin_role()));
create policy devices_admin_update on public.devices for update to authenticated using (public.member_access_allowed() and public.can_manage_system()) with check (public.member_access_allowed() and public.can_manage_system());
create policy cards_read_self_or_admin on public.member_cards for select to authenticated using (public.member_access_allowed() and (user_id=auth.uid() or public.has_admin_role()));
create policy cards_insert_self_or_manager on public.member_cards for insert to authenticated with check (public.member_access_allowed() and (user_id=auth.uid() or public.can_manage_system()));
create policy cards_update_self_or_manager on public.member_cards for update to authenticated using (public.member_access_allowed() and (user_id=auth.uid() or public.can_manage_system())) with check (public.member_access_allowed() and (user_id=auth.uid() or public.can_manage_system()));
create policy cards_delete_self_or_manager on public.member_cards for delete to authenticated using (public.member_access_allowed() and (user_id=auth.uid() or public.can_manage_system()));
create policy assets_read_self_or_admin on public.card_assets for select to authenticated using (public.member_access_allowed() and (user_id=auth.uid() or public.has_admin_role()));
create policy assets_insert_self_or_manager on public.card_assets for insert to authenticated with check (public.member_access_allowed() and (user_id=auth.uid() or public.can_manage_system()));
create policy assets_update_self_or_manager on public.card_assets for update to authenticated using (public.member_access_allowed() and (user_id=auth.uid() or public.can_manage_system())) with check (public.member_access_allowed() and (user_id=auth.uid() or public.can_manage_system()));
create policy assets_delete_self_or_manager on public.card_assets for delete to authenticated using (public.member_access_allowed() and (user_id=auth.uid() or public.can_manage_system()));
create policy settings_admin_read on public.system_settings for select to authenticated using (public.member_access_allowed() and public.has_admin_role());
create policy settings_superadmin_write on public.system_settings for all to authenticated using (public.member_access_allowed() and public.is_super_admin()) with check (public.member_access_allowed() and public.is_super_admin());
create policy logs_admin_read on public.activity_logs for select to authenticated using (public.member_access_allowed() and public.has_admin_role());
create policy pending_no_client_access on public.pending_activations for select to authenticated using (false);
create policy control_no_client_access on public.team_ghaith_system_control for select to authenticated using (false);
create policy sessions_self_or_superadmin on public.team_ghaith_member_sessions for select to authenticated using (public.member_access_allowed() and (user_id=auth.uid() or public.is_super_admin()));
create policy emergency_events_superadmin on public.team_ghaith_emergency_events for select to authenticated using (public.is_super_admin());

revoke all on all tables in schema public from anon,authenticated;
revoke all on public.profiles,public.admin_roles,public.licenses,public.pending_activations,public.team_ghaith_system_control,public.team_ghaith_emergency_events from anon,authenticated;
grant select on public.profiles,public.admin_roles,public.licenses,public.license_activations,public.team_ghaith_member_sessions,public.team_ghaith_emergency_events to authenticated;
grant update(full_name,phone) on public.profiles to authenticated;

grant select,insert,update,delete on public.member_cards,public.card_assets to authenticated;
grant select,update(revoked_at) on public.devices to authenticated;
grant select on public.profiles,public.license_activations,public.devices,public.system_settings,public.activity_logs to authenticated;
revoke all on function public.is_super_admin() from public,anon;
revoke all on function public.has_admin_role() from public,anon;
revoke all on function public.can_manage_system() from public,anon;
revoke all on function public.maintenance_is_enabled() from public,anon;
revoke all on function public.member_access_allowed() from public,anon;
revoke all on function public.register_member_session(text,text) from public,anon;
revoke all on function public.set_emergency_lock(boolean) from public,anon;
grant execute on function public.is_super_admin() to authenticated;
grant execute on function public.has_admin_role() to authenticated;
grant execute on function public.can_manage_system() to authenticated;
grant execute on function public.maintenance_is_enabled() to authenticated;
grant execute on function public.member_access_allowed() to authenticated;
grant execute on function public.emergency_is_locked() to anon,authenticated;
grant execute on function public.register_member_session(text,text) to authenticated;
grant execute on function public.set_emergency_lock(boolean) to authenticated;

-- Storage bucket for private member uploads. Policies enforce member folder isolation.
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
values('member-assets','member-assets',false,10485760,array['image/png','image/jpeg','image/webp'])
on conflict(id) do nothing;
create policy member_assets_read on storage.objects for select to authenticated using (bucket_id='member-assets' and public.member_access_allowed() and (storage.foldername(name))[1]=auth.uid()::text);
create policy member_assets_insert on storage.objects for insert to authenticated with check (bucket_id='member-assets' and public.member_access_allowed() and (storage.foldername(name))[1]=auth.uid()::text);
create policy member_assets_delete on storage.objects for delete to authenticated using (bucket_id='member-assets' and public.member_access_allowed() and (storage.foldername(name))[1]=auth.uid()::text);

create or replace function public.revoke_my_device(p_device_id uuid)
returns boolean language plpgsql security definer set search_path=public,auth as $$
declare sid uuid;
begin
 if auth.uid() is null then raise exception 'Authentication required'; end if;
 update public.devices set revoked_at=now() where id=p_device_id and user_id=auth.uid() and revoked_at is null returning session_id into sid;
 if sid is null then raise exception 'Device not found or already revoked'; end if;
 update public.team_ghaith_member_sessions set revoked_at=now() where session_id=sid and user_id=auth.uid();
 return true;
end; $$;
revoke all on function public.revoke_my_device(uuid) from public,anon;
grant execute on function public.revoke_my_device(uuid) to authenticated;

create or replace function public.touch_updated_at()
returns trigger language plpgsql as $$ begin new.updated_at=now(); return new; end; $$;
drop trigger if exists profiles_touch_updated_at on public.profiles;
create trigger profiles_touch_updated_at before update on public.profiles for each row execute function public.touch_updated_at();
drop trigger if exists cards_touch_updated_at on public.member_cards;
create trigger cards_touch_updated_at before update on public.member_cards for each row execute function public.touch_updated_at();

create or replace function public.protect_member_card_number()
returns trigger language plpgsql security definer set search_path=public as $$
declare official_number text;
begin
 select member_number into official_number from public.profiles where id=new.user_id;
 if official_number is not null and jsonb_typeof(new.card_data->'values')='array' then
   new.card_data := jsonb_set(new.card_data,'{values,1}',to_jsonb(official_number),true);
 end if;
 return new;
end; $$;
drop trigger if exists protect_member_card_number_trigger on public.member_cards;
create trigger protect_member_card_number_trigger before insert or update on public.member_cards for each row execute function public.protect_member_card_number();

create or replace function public.admin_set_member_status(p_user_id uuid,p_status text)
returns boolean language plpgsql security definer set search_path=public,auth as $$
begin
 if not public.can_manage_system() then raise exception 'Admin permission required'; end if;
 if p_status not in ('active','suspended','revoked') then raise exception 'Invalid member status'; end if;
 update public.profiles set status=p_status where id=p_user_id;
 if not found then raise exception 'Member not found'; end if;
 if p_status<>'active' then
   update public.team_ghaith_member_sessions set revoked_at=now() where user_id=p_user_id and revoked_at is null;
   update public.devices set revoked_at=now() where user_id=p_user_id and revoked_at is null;
 end if;
 insert into public.activity_logs(actor_id,action,target_type,target_id,details) values(auth.uid(),'member_status_changed','member',p_user_id::text,jsonb_build_object('status',p_status));
 return true;
end; $$;
create or replace function public.admin_revoke_device(p_device_id uuid)
returns boolean language plpgsql security definer set search_path=public,auth as $$
declare sid uuid;
begin
 if not public.can_manage_system() then raise exception 'Admin permission required'; end if;
 update public.devices set revoked_at=now() where id=p_device_id and revoked_at is null returning session_id into sid;
 if sid is null then raise exception 'Device not found or already revoked'; end if;
 update public.team_ghaith_member_sessions set revoked_at=now() where session_id=sid;
 insert into public.activity_logs(actor_id,action,target_type,target_id) values(auth.uid(),'device_revoked','device',p_device_id::text);
 return true;
end; $$;
create or replace function public.superadmin_set_setting(p_key text,p_value jsonb)
returns boolean language plpgsql security definer set search_path=public,auth as $$
begin
 if not public.is_super_admin() then raise exception 'Super Admin permission required'; end if;
 if p_key not in ('maintenance','device_limit','new_activations') then raise exception 'Setting not allowed'; end if;
 if p_key='device_limit' and coalesce((p_value->>'value')::integer,0) not between 1 and 20 then raise exception 'Device limit must be between 1 and 20'; end if;
 insert into public.system_settings(key,value,updated_at,updated_by) values(p_key,p_value,now(),auth.uid())
 on conflict(key) do update set value=excluded.value,updated_at=now(),updated_by=auth.uid();
 insert into public.activity_logs(actor_id,action,target_type,details) values(auth.uid(),'system_setting_changed','setting',jsonb_build_object('key',p_key,'value',p_value));
 return true;
end; $$;
revoke all on function public.admin_set_member_status(uuid,text) from public,anon;
revoke all on function public.admin_revoke_device(uuid) from public,anon;
revoke all on function public.superadmin_set_setting(text,jsonb) from public,anon;
grant execute on function public.admin_set_member_status(uuid,text) to authenticated;
grant execute on function public.admin_revoke_device(uuid) to authenticated;
grant execute on function public.superadmin_set_setting(text,jsonb) to authenticated;

create or replace function public.admin_set_license_status(p_license_id uuid,p_status text)
returns boolean language plpgsql security definer set search_path=public,auth as $$
declare affected_user uuid;
begin
 if not public.can_manage_system() then raise exception 'Admin permission required'; end if;
 if p_status not in ('unused','active','suspended','revoked','expired') then raise exception 'Invalid license status'; end if;
 update public.licenses set status=p_status where id=p_license_id;
 if not found then raise exception 'License not found'; end if;
 update public.license_activations set status=case when p_status='active' then 'active' when p_status='suspended' then 'suspended' when p_status in ('revoked','expired') then 'revoked' else status end where license_id=p_license_id;
 if p_status in ('suspended','revoked','expired') then
   for affected_user in select user_id from public.license_activations where license_id=p_license_id loop
     update public.team_ghaith_member_sessions set revoked_at=now() where user_id=affected_user and revoked_at is null;
     update public.devices set revoked_at=now() where user_id=affected_user and revoked_at is null;
   end loop;
 end if;
 insert into public.activity_logs(actor_id,action,target_type,target_id,details) values(auth.uid(),'license_status_changed','license',p_license_id::text,jsonb_build_object('status',p_status));
 return true;
end; $$;
revoke all on function public.admin_set_license_status(uuid,text) from public,anon;
grant execute on function public.admin_set_license_status(uuid,text) to authenticated;
