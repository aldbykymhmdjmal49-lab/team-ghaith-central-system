revoke execute on function public.emergency_is_locked() from anon;
