-- One-time first Super Admin bootstrap. The expected email is stored as a hash and deleted after use.
insert into public.system_settings(key,value)
values('bootstrap_admin_email_hash','{"sha256":"e6aa5c0b949f93bf33828302801350e0aad7b45c63149318c022cf8da0b1263d"}'::jsonb)
on conflict(key) do nothing;

create or replace function public.bootstrap_first_super_admin(p_user_id uuid)
returns boolean language plpgsql security definer set search_path=public,auth,extensions as $$
declare expected_hash text; actual_hash text;
begin
 select value->>'sha256' into expected_hash from public.system_settings where key='bootstrap_admin_email_hash' for update;
 if expected_hash is null then return false; end if;
 if not exists(select 1 from public.profiles where id=p_user_id and status='active') then return false; end if;
 select encode(extensions.digest(lower(email),'sha256'),'hex') into actual_hash from public.profiles where id=p_user_id;
 if actual_hash is distinct from expected_hash then return false; end if;
 if exists(select 1 from public.admin_roles where role='super_admin') then
  delete from public.system_settings where key='bootstrap_admin_email_hash';
  return false;
 end if;
 insert into public.admin_roles(user_id,role) values(p_user_id,'super_admin')
 on conflict(user_id) do update set role='super_admin';
 delete from public.system_settings where key='bootstrap_admin_email_hash';
 insert into public.activity_logs(actor_id,action,target_type,details)
 values(p_user_id,'first_super_admin_bootstrapped','system','{"method":"one_time_verified_email"}'::jsonb);
 return true;
end;
$$;
revoke all on function public.bootstrap_first_super_admin(uuid) from public,anon,authenticated;
grant execute on function public.bootstrap_first_super_admin(uuid) to service_role;

-- A single-use permanent license for the first verified administrator account.
insert into public.licenses(code_hash,code_hint,license_type,activation_limit,activation_count,status,note)
values('6d16d349420276e5f796e0f495616e7a5732c9112fb6f1b9b2b655c94fabd802','26EB64','permanent',1,0,'unused','Initial one-time Super Admin bootstrap license')
on conflict(code_hash) do nothing;
