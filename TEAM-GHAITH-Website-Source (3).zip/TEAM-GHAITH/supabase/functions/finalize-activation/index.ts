import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const cors={"Access-Control-Allow-Origin":Deno.env.get("ALLOWED_ORIGIN")??"http://localhost:5173","Access-Control-Allow-Headers":"authorization, x-client-info, apikey, content-type","Access-Control-Allow-Methods":"POST, OPTIONS"};
const reply=(body:unknown,status=200)=>new Response(JSON.stringify(body),{status,headers:{...cors,"Content-Type":"application/json"}});
Deno.serve(async req=>{
 if(req.method==="OPTIONS")return new Response("ok",{headers:cors}); if(req.method!=="POST")return reply({error:"Method not allowed"},405);
 const auth=req.headers.get("Authorization"); if(!auth?.startsWith("Bearer "))return reply({error:"تحقق من البريد أولًا"},401);
 try{
  const url=Deno.env.get("SUPABASE_URL")!,anon=Deno.env.get("SUPABASE_ANON_KEY")!,service=Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
  const userClient=createClient(url,anon,{global:{headers:{Authorization:auth}},auth:{persistSession:false}}); const {data:{user},error:ue}=await userClient.auth.getUser();
  if(ue||!user?.email)return reply({error:"جلسة التحقق غير صالحة"},401);
  const {pendingId}=await req.json(); if(typeof pendingId!=="string")return reply({error:"طلب التفعيل غير صالح"},400);
  const admin=createClient(url,service,{auth:{persistSession:false}});
  const {data:licenseId,error}=await admin.rpc("finalize_pending_activation",{p_pending_id:pendingId,p_user_id:user.id,p_email:user.email});
  if(error)return reply({error:error.message.includes("Activation")||error.message.includes("License")?error.message:"تعذر إكمال التفعيل"},400);
  return reply({success:true,licenseId,message:"تم تفعيل العضوية بنجاح. سجّل الدخول للمتابعة."});
 }catch{return reply({error:"حدث خطأ أثناء إكمال التفعيل"},500);}
});
