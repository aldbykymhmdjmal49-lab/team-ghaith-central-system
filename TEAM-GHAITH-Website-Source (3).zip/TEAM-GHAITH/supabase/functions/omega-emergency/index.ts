// Supabase Edge Function: omega-emergency
// Required secrets: SUPABASE_URL, SUPABASE_ANON_KEY, OMEGA_COMMAND_SHA256
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": Deno.env.get("ALLOWED_ORIGIN") ?? "http://localhost:5173",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

async function sha256Hex(value: string): Promise<string> {
  const bytes = new TextEncoder().encode(value.normalize("NFC"));
  const digest = await crypto.subtle.digest("SHA-256", bytes);
  return [...new Uint8Array(digest)].map((b) => b.toString(16).padStart(2, "0")).join("");
}

function constantTimeEqual(a: string, b: string): boolean {
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  const json = (body: unknown, status = 200) =>
    new Response(JSON.stringify(body), {
      status,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });

  if (req.method !== "POST") return json({ error: "Method not allowed" }, 405);

  const authorization = req.headers.get("Authorization");
  if (!authorization?.startsWith("Bearer ")) return json({ error: "Authentication required" }, 401);

  const url = Deno.env.get("SUPABASE_URL");
  const anonKey = Deno.env.get("SUPABASE_ANON_KEY");
  if (!url || !anonKey) return json({ error: "Server configuration incomplete" }, 500);

  const supabase = createClient(url, anonKey, {
    global: { headers: { Authorization: authorization } },
    auth: { persistSession: false, autoRefreshToken: false },
  });

  const { data: userData, error: userError } = await supabase.auth.getUser();
  if (userError || !userData.user) return json({ error: "Invalid session" }, 401);

  let body: { action?: string; command?: string };
  try {
    body = await req.json();
  } catch {
    return json({ error: "Invalid request body" }, 400);
  }

  // Register a freshly authenticated member session after login.
  // This path is deliberately separate from the secret emergency command.
  if (body.action === "register_session") {
    const { data, error } = await supabase.rpc("register_member_session");
    if (error) return json({ error: error.message }, 403);
    return json({ success: true, registered: Boolean(data) });
  }

  if (body.action !== "lock" && body.action !== "restore") {
    return json({ error: "Unsupported action" }, 400);
  }

  const expectedHash = Deno.env.get("OMEGA_COMMAND_SHA256")?.trim().toLowerCase();
  if (!expectedHash || !/^[a-f0-9]{64}$/.test(expectedHash)) {
    return json({ error: "Emergency command is not configured on the server" }, 503);
  }
  if (typeof body.command !== "string" || body.command.length > 128) {
    return json({ error: "Invalid emergency command" }, 400);
  }

  const suppliedHash = await sha256Hex(body.command);
  if (!constantTimeEqual(suppliedHash, expectedHash)) {
    return json({ error: "Invalid emergency command" }, 403);
  }

  // The database RPC independently verifies the caller's Super Admin role.
  // The command itself is never written to logs or the database.
  const { data, error } = await supabase.rpc("set_emergency_lock", {
    p_enabled: body.action === "lock",
  });
  if (error) {
    const status = error.message.includes("Super Admin") ? 403 : 500;
    return json({ error: status === 403 ? "Super Admin permission required" : "Emergency operation failed" }, status);
  }

  return json({
    success: true,
    locked: body.action === "lock",
    generation: data,
    message: body.action === "lock"
      ? "Emergency lock engaged. Member access and registered sessions have been blocked."
      : "System restored. Members must sign in again to establish new sessions.",
  });
});
