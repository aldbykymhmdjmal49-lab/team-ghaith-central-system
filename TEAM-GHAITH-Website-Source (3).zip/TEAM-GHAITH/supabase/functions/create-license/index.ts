import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const cors={"Access-Control-Allow-Origin":Deno.env.get("ALLOWED_ORIGIN")??"http://localhost:5173","Access-Control-Allow-Headers":"authorization, x-client-info, apikey, content-type","Access-Control-Allow-Methods":"POST, OPTIONS"};
const reply=(body:unknown,status=200)=>new Response(JSON.stringify(body),{status,headers:{...cors,"Content-Type":"application/json"}});
function randomCode(){const bytes=crypto.getRandomValues(new Uint8Array(18));return "TG-"+[...bytes].map(x=>x.toString(16).padStart(2,"0")).join("").toUpperCase().match(/.{1,6}/g)?.join("-");}
async function sha(v:string){const d=await crypto.subtle.digest("SHA-256",new TextEncoder().encode(v));return [...new Uint8Array(d)].map(x=>x.toString(16).padStart(2,"0")).join("");}
Deno.serve(async req=>{
 if(req.method==="OPTIONS")return new Response("ok",{headers:cors});if(req.method!=="POST")return reply({error:"Method not allowed"},405);
 const auth=req.headers.get("Authorization");if(!auth?.startsWith("Bearer "))return reply({error:"Unauthorized"},401);
 try{
  const url=Deno.env.get("SUPABASE_URL")!,anon=Deno.env.get("SUPABASE_ANON_KEY")!,service=Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
  const caller=createClient(url,anon,{global:{headers:{Authorization:auth}},auth:{persistSession:false}});const {data:{user}}=await caller.auth.getUser();if(!user)return reply({error:"Unauthorized"},401);
  const {data:isSuper}=await caller.rpc("is_super_admin");const {data:canManage}=await caller.rpc("can_manage_system");if(!isSuper&&!canManage)return reply({error:"صلاحية الإدارة غير متاحة حاليًا"},403);
  const body=await req.json();const quantity=Math.max(1,Math.min(100,Number(body.quantity)||1));const type=body.licenseType==="temporary"?"temporary":"permanent";const limit=Math.max(1,Math.min(100,Number(body.activationLimit)||1));
  const expiresAt=type==="temporary"&&body.expiresAt?new Date(body.expiresAt).toISOString():null;if(type==="temporary"&&(!expiresAt||new Date(expiresAt)<=new Date()))return reply({error:"حدد تاريخ انتهاء مستقبلي"},400);
  const admin=createClient(url,service,{auth:{persistSession:false}});const issued=Array.from({length:quantity},()=>randomCode()!);
  const records=await Promise.all(issued.map(async code=>({code_hash:await sha(code),code_hint:code.slice(-5),license_type:type,activation_limit:limit,expires_at:expiresAt,created_by:user.id,note:typeof body.note==="string"?body.note.slice(0,250):null})));
  const {error:insertError}=await admin.from("licenses").insert(records);if(insertError)throw insertError;
  await admin.from("activity_logs").insert({actor_id:user.id,action:"licenses_created",target_type:"license",details:{quantity,type,activationLimit:limit}});
  return reply({success:true,codes:issued});
 }catch{return reply({error:"تعذر إنشاء التراخيص"},500);}
});
