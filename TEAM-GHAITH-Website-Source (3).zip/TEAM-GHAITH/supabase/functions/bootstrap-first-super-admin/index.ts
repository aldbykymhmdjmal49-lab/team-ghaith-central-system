import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const cors={"Access-Control-Allow-Origin":"*","Access-Control-Allow-Headers":"authorization, x-client-info, apikey, content-type","Access-Control-Allow-Methods":"POST, OPTIONS"};
const reply=(body:unknown,status=200)=>new Response(JSON.stringify(body),{status,headers:{...cors,"Content-Type":"application/json"}});
Deno.serve(async req=>{
 if(req.method==="OPTIONS")return new Response("ok",{headers:cors});
 if(req.method!=="POST")return reply({error:"Method not allowed"},405);
 const authorization=req.headers.get("Authorization");
 if(!authorization?.startsWith("Bearer "))return reply({error:"Authentication required"},401);
 try{
  const url=Deno.env.get("SUPABASE_URL")!,anon=Deno.env.get("SUPABASE_ANON_KEY")!,service=Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
  const caller=createClient(url,anon,{global:{headers:{Authorization:authorization}},auth:{persistSession:false}});
  const {data:{user},error}=await caller.auth.getUser();
  if(error||!user)return reply({error:"Invalid session"},401);
  const admin=createClient(url,service,{auth:{persistSession:false}});
  const {data:promoted,error:promotionError}=await admin.rpc("bootstrap_first_super_admin",{p_user_id:user.id});
  if(promotionError)return reply({error:"Bootstrap operation failed"},500);
  return reply({success:Boolean(promoted),message:promoted?"First Super Admin role granted.":"No bootstrap promotion is available for this account."},promoted?200:403);
 }catch{return reply({error:"Bootstrap operation failed"},500);}
});
