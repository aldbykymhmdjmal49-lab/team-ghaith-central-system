import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const cors={"Access-Control-Allow-Origin":Deno.env.get("ALLOWED_ORIGIN")??"http://localhost:5173","Access-Control-Allow-Headers":"authorization, x-client-info, apikey, content-type","Access-Control-Allow-Methods":"POST, OPTIONS"};
const reply=(body:unknown,status=200)=>new Response(JSON.stringify(body),{status,headers:{...cors,"Content-Type":"application/json"}});
async function sha(value:string){const b=await crypto.subtle.digest("SHA-256",new TextEncoder().encode(value.trim().toUpperCase()));return [...new Uint8Array(b)].map(x=>x.toString(16).padStart(2,"0")).join("");}
Deno.serve(async req=>{
 if(req.method==="OPTIONS")return new Response("ok",{headers:cors}); if(req.method!=="POST")return reply({error:"Method not allowed"},405);
 try{
  const {licenseCode,fullName,phone,email,consent}=await req.json();
  if(consent!==true)return reply({error:"يجب الموافقة على سياسة الاستخدام والخصوصية"},400);
  if(typeof licenseCode!=="string"||licenseCode.length<6||licenseCode.length>100||typeof fullName!=="string"||fullName.trim().length<3||typeof phone!=="string"||phone.trim().length<6||typeof email!=="string"||!/^\S+@\S+\.\S+$/.test(email))return reply({error:"راجع البيانات المدخلة"},400);
  const url=Deno.env.get("SUPABASE_URL")!, service=Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!, anon=Deno.env.get("SUPABASE_ANON_KEY")!;
  const admin=createClient(url,service,{auth:{persistSession:false}}); const publicClient=createClient(url,anon,{auth:{persistSession:false}});
  const {data:lock}=await admin.from("team_ghaith_system_control").select("emergency_locked").eq("singleton_id",1).single();
  const {data:settings}=await admin.from("system_settings").select("key,value").in("key",["maintenance","new_activations"]);
  const maintenance=settings?.find(x=>x.key==="maintenance")?.value as {enabled?:boolean}|undefined;
  const activations=settings?.find(x=>x.key==="new_activations")?.value as {enabled?:boolean}|undefined;
  if(lock?.emergency_locked||maintenance?.enabled)return reply({error:"النظام متوقف مؤقتًا بواسطة الإدارة"},503);
  if(activations?.enabled===false)return reply({error:"التفعيلات الجديدة متوقفة حاليًا"},503);
  const hash=await sha(licenseCode); const {data:lic,error:le}=await admin.from("licenses").select("id,status,activation_count,activation_limit,expires_at").eq("code_hash",hash).maybeSingle();
  if(le||!lic||["revoked","suspended","expired"].includes(lic.status)||(lic.expires_at&&new Date(lic.expires_at)<=new Date())||lic.activation_count>=lic.activation_limit)return reply({error:"كود التفعيل غير صالح أو منتهي أو استنفد عدد مرات الاستخدام"},400);
  const normalized=email.trim().toLowerCase(); const {data:existingMember}=await admin.from("profiles").select("id").eq("email",normalized).maybeSingle();
  if(existingMember)return reply({error:"هذا البريد مرتبط بعضوية مفعّلة بالفعل. استخدم تسجيل الدخول."},409);
  const since=new Date(Date.now()-60_000).toISOString();
  const {count}=await admin.from("pending_activations").select("id",{count:"exact",head:true}).eq("email",normalized).gte("created_at",since);
  if((count??0)>=1)return reply({error:"انتظر 60 ثانية قبل طلب رمز جديد"},429);
  const {data:pending,error:pe}=await admin.from("pending_activations").insert({email:normalized,full_name:fullName.trim(),phone:phone.trim(),license_id:lic.id,expires_at:new Date(Date.now()+5*60_000).toISOString()}).select("id").single();
  if(pe||!pending)return reply({error:"تعذر إنشاء طلب التفعيل"},500);
  const {error:otpError}=await publicClient.auth.signInWithOtp({email:normalized,options:{shouldCreateUser:true,emailRedirectTo:undefined}});
  if(otpError){await admin.from("pending_activations").delete().eq("id",pending.id);return reply({error:"تعذر إرسال رمز البريد. راجع إعداد SMTP في Supabase."},502);}
  return reply({success:true,pendingId:pending.id,message:"تم إرسال رمز التحقق إلى بريدك الإلكتروني. صلاحية طلب التفعيل 5 دقائق."});
 }catch{return reply({error:"حدث خطأ أثناء طلب التفعيل"},500);}
});
