# TEAM GHAITH — Phase 1 Source Audit

## Scope and files received
- `Card-ID-BUC-original.html` — received, 3,858,660 characters, 805 lines, approximately 3.69 MiB.
- `project-specification.txt` — received, 15,638 characters, 761 lines.
- **TEAM GHAITH Starter ZIP was not present among the uploaded files.** This audit therefore covers the supplied HTML and specification only; it does not claim to have inspected the missing starter project.

## Original card studio inventory
- Document title: `TEAM GHAITH — ID Card Design Studio`.
- Arabic-first document (`lang="ar"`, `dir="rtl"`).
- 98 unique DOM IDs; no duplicate IDs detected.
- 5 inline JavaScript blocks.
- Main script size: 1,704,843 characters; all 5 inline JavaScript blocks passed Node.js v22 syntax checks (`node --check`).
- 0 buttons; no HTML `<form>` elements.
- 4 embedded image data URIs: 2 JPEG and 2 PNG.
- Card geometry: 1044 × 642 aspect ratio; print/export target 104.4 × 64.2 mm.
- Responsive layout includes a breakpoint at 820 px and a separate PDF-cutter layout breakpoint at 850 px.

## Confirmed existing capabilities
1. Two-sided card editor and live preview (front/back).
2. Member fields: full name, ID number, university, faculty, position.
3. Photo upload and photo crop/zoom/position controls.
4. Front/back QR creation, upload, positioning and clearing.
5. Save/load/new card actions.
6. PNG export and print/PDF workflow.
7. PDF/image import and crop/extraction workspace.
8. Front/back artwork template upload and reset.
9. Sticker upload, placement, resizing and deletion on both card faces.
10. Arabic-to-English transliteration helpers and university/faculty/position pickers.
11. WhatsApp contact list and PDF sharing preparation.

## Important implementation findings / migration risks
- Card records are currently stored in browser `localStorage` under `ghyth-membership-cards`; they are not centrally synchronized and are not account-isolated.
- Custom front/back templates are stored in `localStorage` (`teamGhaithFrontTemplate`, `teamGhaithBackTemplate`).
- WhatsApp contacts are stored in `localStorage` (`teamGhaithWhatsAppContactsV1`).
- The original editor is a single large HTML file with embedded artwork and inline scripts. The main script is about 1.7 million characters, largely because the artwork is embedded in the source.
- The QR helper and PDF tools load third-party libraries from public CDNs at runtime; offline operation and CDN availability are dependencies.
- No server-side authentication, license validation, authorization, database persistence, RLS, admin roles, device sessions, or global shutdown enforcement were found in the supplied HTML.
- The original card editor is currently a standalone studio, not yet a member portal. It must be integrated behind server-validated member authorization before release.
- `localStorage` is suitable only for local convenience, not as a security boundary or central source of truth.

## Integrity / preservation
- The supplied original has been copied byte-for-byte to `original/Card-ID-BUC-original.html`.
- SHA-256 of supplied original: `c6cbafac75bbcbc270f4c4b74d8eaa24e3a5dfdbe241ef7dd47f633275fc32ea`.
- Original upload was not modified.

## Phase 1 outcome
**The original card editor is present and its main JavaScript passes a syntax check.** Its key user-facing features can be preserved. The missing Starter ZIP prevents a complete comparison with the intended starter architecture.

## Next implementation steps
1. Obtain the missing TEAM GHAITH Starter ZIP (if it exists) and compare its files, dependencies and existing work.
2. Establish a version-controlled application shell without rewriting the original card artwork/editor prematurely.
3. Design Supabase schema, RLS policies, server-side activation functions and admin authorization.
4. Move member card persistence and assets from browser-only storage to authenticated, per-member cloud storage.
5. Integrate the preserved card studio into the authenticated member portal and enforce server-side global controls.
6. Test auth, OTP delivery, license states, RLS isolation, device revocation, export/print and responsive layouts.
7. Deploy only after credentials are supplied and end-to-end tests pass.

## External setup needed for real deployment
Supabase, Netlify and Resend accounts/projects and their configuration are required. Secret keys must remain server-side and must never be embedded in browser code. No live deployment or email-delivery test has been performed in this audit.
