import { useState } from "react";
import type { SupabaseClient } from "@supabase/supabase-js";

type Props = { supabase: SupabaseClient };

export function OmegaEmergencyPanel({ supabase }: Props) {
  const [command, setCommand] = useState("");
  const [busy, setBusy] = useState<"lock" | "restore" | null>(null);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  async function run(action: "lock" | "restore") {
    setBusy(action);
    setMessage("");
    setError("");
    try {
      const { data: sessionData } = await supabase.auth.getSession();
      if (!sessionData.session) throw new Error("يجب تسجيل دخول Super Admin أولًا.");

      const { data, error: invokeError } = await supabase.functions.invoke("omega-emergency", {
        body: { action, command },
      });
      if (invokeError) throw invokeError;
      if (!data?.success) throw new Error(data?.error || "تعذر تنفيذ الأمر.");

      setMessage(data.message || (action === "lock" ? "تم تفعيل قفل الطوارئ." : "تمت استعادة النظام."));
      setCommand("");
    } catch (e) {
      setError(e instanceof Error ? e.message : "حدث خطأ غير متوقع.");
    } finally {
      setBusy(null);
    }
  }

  return (
    <section dir="rtl" aria-labelledby="omega-title" className="rounded-xl border border-red-300 bg-white p-5 shadow-sm">
      <div className="mb-3 flex items-center gap-2">
        <span aria-hidden className="text-xl">⛔</span>
        <div>
          <h2 id="omega-title" className="font-semibold text-slate-900">MØX//OMEGA — قفل الطوارئ</h2>
          <p className="text-sm text-slate-600">خاص بـ Super Admin فقط. يحجب خدمات الأعضاء ويحافظ على قاعدة البيانات.</p>
        </div>
      </div>

      <label htmlFor="omega-command" className="mb-1 block text-sm font-medium text-slate-800">
        كلمة أمر الطوارئ
      </label>
      <input
        id="omega-command"
        type="password"
        autoComplete="off"
        spellCheck={false}
        value={command}
        onChange={(e) => setCommand(e.target.value)}
        placeholder="أدخل أمر الطوارئ"
        className="w-full rounded-lg border border-slate-300 px-3 py-2 text-left font-mono outline-none focus:border-red-500 focus:ring-2 focus:ring-red-100"
      />

      <div className="mt-3 flex flex-wrap gap-2">
        <button
          type="button"
          disabled={!!busy || !command}
          onClick={() => {
            if (window.confirm("تأكيد قفل جميع خدمات الأعضاء الآن؟ ستظل قاعدة البيانات محفوظة.")) void run("lock");
          }}
          className="rounded-lg bg-red-700 px-4 py-2 text-sm font-semibold text-white disabled:cursor-not-allowed disabled:opacity-50"
        >
          {busy === "lock" ? "جارٍ الإيقاف..." : "تفعيل قفل الطوارئ"}
        </button>
        <button
          type="button"
          disabled={!!busy || !command}
          onClick={() => {
            if (window.confirm("تأكيد استعادة الخدمات؟ سيُطلب من الأعضاء تسجيل الدخول من جديد.")) void run("restore");
          }}
          className="rounded-lg border border-slate-300 px-4 py-2 text-sm font-semibold text-slate-800 disabled:cursor-not-allowed disabled:opacity-50"
        >
          {busy === "restore" ? "جارٍ الاستعادة..." : "استعادة النظام"}
        </button>
      </div>

      {message && <p role="status" className="mt-3 text-sm text-green-700">{message}</p>}
      {error && <p role="alert" className="mt-3 text-sm text-red-700">{error}</p>}
      <p className="mt-3 text-xs leading-5 text-slate-500">
        لا يتم حذف الأعضاء أو البطاقات أو التراخيص. بعد الاستعادة، يجب على العضو تسجيل الدخول مجددًا.
      </p>
    </section>
  );
}
